package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.dao.ChatRoomDao;
import com.example.demo.dto.ChatRoom;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class ChatRoomService {

  @Autowired
  private ChatRoomDao chatRoomDao;

  public ChatRoom getById(int roomId) {
    return chatRoomDao.selectById(roomId); // 없으면 null 반환(컨트롤러에서 처리)
  }

  public boolean isMember(int roomId, int userId) {
    ChatRoom r = chatRoomDao.selectById(roomId);
    if (r == null) return false;
    return userId == r.getChatuser1Id() || userId == r.getChatuser2Id();
  }

  public boolean isApproved(int roomId) {
    ChatRoom r = chatRoomDao.selectById(roomId);
    return r != null && "A".equals(r.getChatroomStatus());
  }

  /**
   * ✅ 방 진입 허용 검사: 멤버가 아니면 IllegalArgumentException,
   *    승인(A) 아니면 IllegalStateException을 던진다.
   *    (컨트롤러에서 try/catch로 403/404 매핑)
   */
  public void assertEntryAllowed(int roomId, int userId) {
    ChatRoom r = chatRoomDao.selectById(roomId);
    if (r == null) throw new RuntimeException("NOT_FOUND");
    if (!(userId == r.getChatuser1Id() || userId == r.getChatuser2Id())) {
      throw new IllegalArgumentException("NOT_MEMBER");
    }
    if (!"A".equals(r.getChatroomStatus())) {
      throw new IllegalStateException("NOT_APPROVED");
    }
  }

  // 방이 존재하지 않으면 생성, 아니면 방의 정보를 반환
  // 기존 방의 조건: 두 유저가 동일하고 상태가 P 또는 A
  @Transactional
  public ChatRoom ensurePairRoom(int userA, int userB, int requestedBy) {
    int u1 = Math.min(userA, userB);
    int u2 = Math.max(userA, userB);

    ChatRoom found = chatRoomDao.selectPairRoom(u1, u2);
    if (found != null) return found;

    ChatRoom room = new ChatRoom();
    room.setChatuser1Id(u1);
    room.setChatuser2Id(u2);
    room.setRequestedBy(requestedBy);
    room.setChatroomStatus("P"); // 최초는 P
    chatRoomDao.insert(room);

    return chatRoomDao.selectPairRoom(u1, u2);
  }

  // (선택) 승인/거절이 필요하면 사용
  @Transactional
  public void approve(int roomId, int byUserId) {
    ChatRoom r = chatRoomDao.selectById(roomId);
    if (r == null) throw new RuntimeException("NOT_FOUND");
    // 멤버만 승인 가능
    if (!(byUserId == r.getChatuser1Id() || byUserId == r.getChatuser2Id())) {
      throw new IllegalArgumentException("NOT_MEMBER");
    }
    chatRoomDao.updateStatus(roomId, "A");
  }

  @Transactional
  public void reject(int roomId, int byUserId) {
    ChatRoom r = chatRoomDao.selectById(roomId);
    if (r == null) throw new RuntimeException("NOT_FOUND");
    if (!(byUserId == r.getChatuser1Id() || byUserId == r.getChatuser2Id())) {
      throw new IllegalArgumentException("NOT_MEMBER");
    }
    chatRoomDao.updateStatus(roomId, "D"); // 거절/종료
  }
}
